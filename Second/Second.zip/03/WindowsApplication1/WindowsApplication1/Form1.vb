﻿Public Class SyB_3

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub SyB_3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        TextBox1.Text = Val(TextBox1.Text) + 1
    End Sub

    Private Sub SyB_3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
